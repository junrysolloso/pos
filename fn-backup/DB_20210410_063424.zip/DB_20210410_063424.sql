#
# TABLE STRUCTURE FOR: tbl_auth_attempts
#

DROP TABLE IF EXISTS `tbl_auth_attempts`;

CREATE TABLE `tbl_auth_attempts` (
  `auth_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `auth_attempts` tinyint(1) NOT NULL,
  `auth_blocked` datetime NOT NULL,
  `auth_user` char(10) DEFAULT NULL,
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_category
#

DROP TABLE IF EXISTS `tbl_category`;

CREATE TABLE `tbl_category` (
  `category_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_category` (`category_id`, `category_name`) VALUES (1, 'pharmacy');
INSERT INTO `tbl_category` (`category_id`, `category_name`) VALUES (2, 'grocery');
INSERT INTO `tbl_category` (`category_id`, `category_name`) VALUES (3, 'beauty products');


#
# TABLE STRUCTURE FOR: tbl_companyinfo
#

DROP TABLE IF EXISTS `tbl_companyinfo`;

CREATE TABLE `tbl_companyinfo` (
  `com_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `com_name` varchar(30) DEFAULT NULL,
  `com_proprietor` varchar(30) DEFAULT NULL,
  `com_tin` varchar(20) DEFAULT NULL,
  `com_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_companyinfo` (`com_id`, `com_name`, `com_proprietor`, `com_tin`, `com_address`) VALUES (1, 'botica jarippre', 'robie m. de los santos', '947-946-050', 'p-5 poblacion, san jose, dinagat islands');


#
# TABLE STRUCTURE FOR: tbl_customer
#

DROP TABLE IF EXISTS `tbl_customer`;

CREATE TABLE `tbl_customer` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(25) DEFAULT NULL,
  `cust_address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_damagestocks
#

DROP TABLE IF EXISTS `tbl_damagestocks`;

CREATE TABLE `tbl_damagestocks` (
  `ds_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` varchar(20) DEFAULT NULL,
  `ds_quantity` int(11) DEFAULT NULL,
  `ds_remarks` varchar(50) DEFAULT NULL,
  `ds_date` date DEFAULT NULL,
  PRIMARY KEY (`ds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_inventory
#

DROP TABLE IF EXISTS `tbl_inventory`;

CREATE TABLE `tbl_inventory` (
  `inv_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` varchar(20) DEFAULT NULL,
  `inv_rem_stocks` int(11) DEFAULT NULL,
  `inv_item_srp` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`inv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_items
#

DROP TABLE IF EXISTS `tbl_items`;

CREATE TABLE `tbl_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` varchar(20) DEFAULT NULL,
  `subcat_id` smallint(6) DEFAULT NULL,
  `item_name` varchar(50) DEFAULT NULL,
  `item_description` varchar(100) DEFAULT NULL,
  `item_critlimit` smallint(6) DEFAULT NULL,
  `brand_name` varchar(100) NOT NULL,
  `generic_name` varchar(100) NOT NULL,
  `unit_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (1, '4806519380024', 2, 'vhellox', '500mg capsule', 50, 'Vhellox', 'Amoxicillin Trihydrate', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (2, '4804272979783', 1, 'himox', '500mg capsule', 10, 'Himox', 'Amoxicillin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (3, '4800301902340', 2, 'moxylor', '100mg/ml drops 10ml', 3, 'Moxylor', 'Amoxicillin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (4, '4800361314053', 4, 'bear brand', '1-3 years 420g jr box', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (5, '4800361388337', 4, 'bear brand fortified', '1200g sachet', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (6, '4800301902357', 2, 'moxylor', '125mg/5ml 60ml', 3, 'Moxylor', 'Amoxicillin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (7, '4800361403986', 4, 'bear brand adult plus', '33g coffee sachet', 12, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (8, '8712045020623', 4, 'sustagen premium adult', '350g box', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (9, '4800301902364', 2, 'moxylor', '250mg/5ml 60ml', 3, 'Moxylor', 'Amoxicillin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (10, '4800221240539', 4, 'pediasure plus 3+', '400g vanilla', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (11, '18906050757132', 2, 'clariwell', '125mg/5ml 50ml', 2, 'Clariwell', 'Clarithromycin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (12, '4800361348706', 4, 'nestogen 3', '340g box', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (13, '18906050757811', 2, 'clariwell', '250mg/5ml 70ml', 2, 'Clariwell', 'Clarithromycin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (14, '4800361348607', 4, 'nestogen 1', '340g box', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (15, '4806525170701', 2, 'klarithix', '500mg tablet', 10, 'Klarithix', 'Clarithromycin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (16, '4800361348645', 4, 'nestogen 2', '340g box 6-12 months', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (17, '4800361397254', 4, 'nido junior', '160g box', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (18, '4806503122197', 2, 'sqcef', '250mg/5ml 50ml', 2, 'SQCEF', 'Cefuroxime Axetil', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (19, '4800361363129', 4, 'nestogen classic infant formula', '135g sachet 0-12 months', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (20, '18906045600412', 2, 'theoroxime', '500mg tablet', 20, 'Theoroxime', 'Cefuroxime', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (21, '4800301903262', 2, 'dialox', '250mg/5ml 60ml', 2, 'Dialox', 'Cloxacillin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (22, '4800361373562', 4, 'nido junior 1-3 years', '370g  box', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (23, '18908005368110', 2, 'cloxane', '500mg capsule', 20, 'Cloxane', 'Cloxacillin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (24, '8906011513497', 2, 'sanix', '200mg tablet', 10, 'Sanix', 'Cefixime', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (25, '4804272979378', 2, 'cefixsaph', '100mg/5ml 60ml', 2, 'Cefixsaph', 'Cefixime Tryhydrate', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (26, '480427657207', 2, 'cephalosporin', '20mg/ml drops 10ml', 2, 'Cephalosporin', 'Cefixime', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (27, '4800153151248', 4, 'bonamil 6-12 months', '350g box', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (28, '4800301902517', 2, 'diacef', '125mg/5ml 60ml', 3, 'Diacef', 'Cefalexin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (29, '4800153151231', 4, 'bonna infant formula', '350g box 0-6 months', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (30, '4800301902524', 2, 'diacef', '250mg/5ml 60ml', 3, 'Diacef', 'Cefalexin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (31, '4800301902500', 2, 'diacef', '100mg/ml drops 10ml', 3, 'Diacef', 'Cefalexin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (32, '4800221239427', 4, 'similac gain plus', '400g box 1-3 years old', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (33, '4806523301862', 1, 'exel', '125mg/5ml 60ml', 3, 'Exel', 'Cefalexin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (34, '8712045027165', 4, 'enfagrow a+', '1-3 years old 350g box', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (35, '4806523301893', 2, 'exel', '500mg capsule', 30, 'Exel', 'Cefalexin', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (36, '4806501597980', 4, 'anlene', 'white coffee 300g 10 serves', 3, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (37, '4800301902494', 2, 'ceflor', '250mg/5ml 60ml', 2, 'Ceflor', 'Cefaclor', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (38, '4806501597454', 4, 'anlene', 'chocolate 300g 7 serves', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (39, '9556001132468', 12, 'cerelac infant cereals', '250g box wheat banana and milk', 5, 'NA', 'NA', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (40, '4800301902487', 2, 'ceflor', '125mg/5ml 60ml', 2, 'Ceflor', 'Cefaclor', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (41, '4800301902463', 2, 'ceflor', '50mg/ml drops 20ml', 2, 'ceflor', 'cefaclor', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (42, '9556001132048', 12, 'cerelac infant cereals', '250g box mixed fruits and soya', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (43, '4800301902845', 2, 'metrozole', '125mg/5ml 60ml', 2, 'metrozole', 'metronidazole', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (44, '4806523302241', 2, 'flagex', '500mg tablet', 20, 'flagex', 'metronidazole', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (45, '9556001132291', 12, 'cerelac infant cereals', '250g box rice and soya', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (46, '4806501597416', 4, 'anlene', 'plain 300g 8 serves', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (47, '4806523302067', 2, 'kathrex', '960mg tablet', 20, 'kathrex', 'cotrimoxazole', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (48, '4806523302029', 2, 'kathrex', '240mg/5ml 60ml', 2, 'kathrex', 'cotrimoxazole', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (49, '6947790794020', 10, 'pomegranate', 'grenade moistening and smoothing mask 30g', 3, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (50, '4807788571137', 1, 'amoclav', '312.5mg/5ml 60ml', 1, 'amoclav', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (51, '4800274040018', 12, 'quaker instant oatmeal', '400g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (52, '4804276348042', 10, 'vitamin e', 'star snow muscle perfect black mask 30g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (53, '4800186004917', 12, 'golden oats plus', '200g (7.05 oz) chocolate', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (54, '8906016610030', 2, 'comxicla', '250mg/62.5mg/5ml 60ml', 1, 'comxicla', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (55, '4809012480017', 10, 'skinmate shark oil', '15 ml original', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (56, '4800888176851', 10, 'master', 'oil control max/facial scrub/4g', 10, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (57, '4800343860776', 2, 'clovimed', '400mg/57mg/5ml 70ml', 1, 'clovimed', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (58, '4801010121244', 10, 'johnsons baby cologne', '125 ml bounce', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (59, '4800888139641', 10, 'ponds', 'white beauty/pore conditioning toner/100ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (60, '4801010127314', 10, 'johnsons baby cologne', '125 ml heaven gentle and mild scented', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (61, '4804274419607', 2, 'co-amoxisaph', '125mg/31.25mg/5ml 60ml', 1, 'co-amoxisaph', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (62, '4807788520906', 1, 'amoclav', '457mg/5ml 70ml', 1, 'amoclav', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (63, '4806789446826', 10, 'master', 'active whitening/deep cleanser/70ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (64, '4807788520890', 1, 'amoclav', '457mg/5ml 35ml', 1, 'amoclav', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (65, '4806789442163', 10, 'eskinol papaya smooth white', '135ml (4.6fl.oz) facial deep cleanser with pure papaya extract', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (66, '6947790784830', 10, 'blueberry', 'moisturizing mask/30g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (67, '18906016610112', 2, 'comxicla', '625mg tablet', 10, 'comxicla', 'co-amoxiclav', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (68, '4800888192882', 10, 'ponds men', 'energy charge/whitening face wash/10g', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (69, '4800888210449', 10, 'rexona dry serum natural whitening', '50ml fresh rose', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (70, '4800204002024', 1, 'betadine solution', '120ml', 1, 'betadine', 'povidone-iodine', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (71, '4902430408097', 10, 'olay', 'natural white/whitening cream/uv protection/7.5g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (72, '4800204002017', 2, 'betadine solution', '60ml', 1, 'betadine', 'povidone-iodine', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (73, '4800135001417', 10, 'ph care intimate wash', '50ml happy daisies', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (74, '4800888143891', 10, 'ponds', 'white beauty/facial foam/10g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (75, '4800204002048', 1, 'betadine solution', '15ml', 1, 'betadine', 'povidone-iodine', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (76, '48035880', 1, 'betadine solution', '7.5ml', 1, 'betadine', 'povidone-iodine', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (77, '4800135006542', 10, 'ph care daily feminine wash', '50ml natural protection with guava leaf extract', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (78, '4902430749756', 10, 'olay', 'natural white/light/uv protection/whitening cream/7.5g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (79, '8851932349130', 10, 'axe black', '50 ml', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (80, '8851932401289', 10, 'axe ice chill deodorant body spray', '50ml', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (81, '4800888143860', 10, 'ponds', 'white beauty/normal skin/super cream/12g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (82, '4800067453513', 1, 'rhea hydrogen pyroxide', '10 volumes 120ml', 1, 'rhea', 'hydrogen pyroxide', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (83, '8851932371551', 10, 'axe you deodorant body spray', '50ml', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (84, '4800067453544', 1, 'rhea hydrogen pyroxide', '20 volumes 120ml', 1, 'rhea', 'hydrogen pyroxide', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (85, '4800135003113', 10, 'ph care', 'intimate wash/passionate bloom/dual hydrating moisturizers/5ml', 10, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (86, '8850007011187', 10, 'johnsons baby powder blossoms', '200g', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (87, '4806515981348', 2, 'ephic eucalytus', '15ml', 1, 'ephic', 'eucalyptus', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (88, '4806789446833', 10, 'master active whitening with papaya extract', '135ml zeroil deep cleanser', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (89, '4987176600769', 2, 'vicks  vaporub', '5g', 1, 'vicks vaporub', 'camphor,menthol,eucalytus oil', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (90, '4987176600776', 1, 'vicks vaporub', '10g', 1, 'vicks vaporub', 'camphor,menthol,eucalytus oil', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (91, '4800204008651', 10, 'povidone-iodine betadine feminine wash', '25ml  7.5% solution antiseptic', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (92, '4800003439526', 10, 'eskinol', 'classic white/facial deep cleanser/225ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (93, '4987176009678', 1, 'vicks vaporub', '25g', 1, 'vicks vaporub', 'camphor,menthol,eucalytus oil', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (94, '4987176601285', 1, 'vicks vaporub', '50g', 1, 'vicks vaporub', 'camphor,menthol,eucalyptus oil', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (95, '4800888196255', 10, 'eskinol mild for teens facial deep cleanser', '225ml', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (96, '8938503445207', 10, 'lactacyd', 'white intimate/whitening daily feminine wash/150ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (97, '4987176013491', 1, 'vicks inhaler', '0.5ml', 1, 'vicks inhaler', 'camphor + menthol', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (98, '4806789442156', 10, 'eskinol papaya smooth white', '225ml (7.6fl.oz) facial deep cleanser with pure papaya extract', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (99, '4806501597973', 4, 'anlene', 'white coffee/30g 1 serve', 12, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (100, '4987176003430', 1, 'vicks formula 44', '100ml', 1, 'vicks formula 44', 'dextromethorphan hbr', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (101, '4800119214680', 10, 'skinwhite whitening facial cleanser', '135ml power whitening bioprotectant formula', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (102, '4987176003423', 1, 'vicks formula 44', '54ml', 1, 'vicks formula 44', 'dextromethorphan hbr', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (103, '4800135003107', 10, 'ph care', 'intimate wash/cool wind/active cool/5ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (104, '4806789010003', 10, 'fissan prickly heat powder', '50g', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (105, '4987072081808', 1, 'kool fever', 'baby 0-2', 1, 'kool fever', 'kool fever', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (106, '4987072005538', 1, 'kool fever', 'kids', 1, 'kool fever', 'kool fever', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (107, '7800888212429', 10, 'fissan soothing relief baby powder', '50g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (108, '8850007010869', 10, 'johnson\'s', 'bedtime baby powder/200g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (109, '4987072006160', 1, 'kool fever', 'adults', 1, 'kool fever', 'kool fever', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (110, '4801010105107', 10, 'johnsons baby powder blossoms', '50g', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (111, '4806526296820', 1, 'partners gauze pad', 'sterile 4x4x8 ply', 1, 'partners', 'gauze pad', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (112, '48033459', 10, 'johnsons baby powder', '50g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (113, '8850007014492', 10, 'johnson\'s', 'active fresh baby powder/200g', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (114, '4809030034018', 1, 'partners gauze bandage', '3x10 yards', 1, 'partners', 'gauze bandage', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (115, '9318637043330', 6, 'cetaphil baby shampoo with natural chamomile', '200 ml hair', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (116, '9556006062074', 6, 'johnson\'s', 'top-to-toe baby bath/50ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (117, '4800067551165', 1, 'mediplast bantam', 'plastic strips', 1, 'bantam', 'mediplast', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (118, '9318637044009', 6, 'cetaphil baby gentle wash and shampoo with glyceri', '400ml hair and body', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (119, '30707387005086', 1, 'micropore tape', '1/2 inch', 1, 'micropore tape', 'plaster', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (120, '4800119219128', 10, 'vitress', 'cuticle coat/hair repair/hydro restore system/15ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (121, '30707387065974', 1, 'micropore tape', '1 inch', 1, 'micropore tape', 'plaster', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (122, '4804279363677', 10, 'cheek lip', 'lovely peach', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (123, '48038683', 6, 'cetaphil gentle skin cleanser', '60ml face and body', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (124, '7707331802084', 1, 'leukoplast', '1.25cmx5m', 1, 'leukoplast', 'plaster', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (125, '4806016000777', 10, 'cetaphil baby daily lotion with shea butter', '50ml face and body', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (126, '4800011121512', 5, 'ethyl alcohol', 'casino/70% solution/antiseptic disinfectant/150ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (127, '302993921400', 10, 'cetaphil gentle skin cleanser', '118ml face and body', 3, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (128, '4800011122212', 5, 'ethyl alcohol', 'casino femme/dual moisturizer/70% solution/150ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (129, '9318637043316', 10, 'cetaphil baby daily lotion with shea butter', '400ml face and body', 2, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (130, '4800135003183', 10, 'myra', 'classic moisturizing/vitamin lotion/grape seed oil & 24-hr moisture lock/200ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (131, '8850007814405', 5, 'listerine total care zero alcohol mouthwash', '100ml lavender', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (132, '4809012730952', 2, 'ceres toothache drops', '5ml', 1, 'cloveoil//creosote', 'toothache drops', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (133, '8850007814382', 5, 'listerine total care mouthwash', '100ml lavender', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (134, '8850007814290', 5, 'listerine cool mint mouthwash', '100ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (135, '8850007814429', 5, 'listerine cool mint zero alcohol mouthwash', '100 ml', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (136, '4800135003268', 10, 'myra', 'classic whitening vitamin lotion/actilight & uv protection/200ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (137, '4806530875752', 2, 'cardinal digital thermometer', '1\'s', 1, 'cardinal', 'digital thermometer', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (138, '8850007814375', 5, 'listerine tartar control mouthwash', '100ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (139, '382906702012', 1, 'bd insulin syringe', '1ml', 1, 'bd insulin', 'syringe', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (140, '4800136111054', 6, 'lactacyd', 'natural skin cleaning and protection/baby bath/150ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (141, '4800119222036', 10, 'skinwhite powerwhitening lotion', '200ml kojic acid spf20', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (142, '4806530871143', 2, 'cardinal care syringe', '3ml', 1, 'cardinal care', 'syringe', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (143, '4800119211290', 10, 'skinwhite classic whitening lotion', '200ml light feel technology spf20', 4, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (144, '4809012480024', 10, 'skinmate', 'shark oil/for facial care original whitening oil/7.5ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (145, '4806507831071', 10, 'silka whitening lotion papaya', '200ml spf6', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (146, '9556006060636', 10, 'johnsons baby oil bedtime', '50ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (147, '4800011121536', 5, 'ethyl alcohol', 'casino/70% solution/500ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (148, '4804274682445', 2, 'pro care nebulizer adult', 'mask', 1, 'pro health care', 'nebulizer mask', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (149, '4800011122236', 5, 'casino ethyl alcohol femme 70% solution', '500ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (150, '4800011159034', 13, 'aceite de manzanilla', '50ml 0.2ml/ 100ml solution', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (151, '4800011159041', 13, 'aceite de manzanilla', '100ml 0.2ml/100ml solution', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (152, '4806502790274', 1, 'watsonal castoria', '60ml', 1, 'boie', 'watsonal castoria', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (153, '48035156', 13, 'efficascent oil extra strength', '25ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (154, '4800011133430', 13, 'efficascent oil extra strength', '50ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (155, '4806502790267', 1, 'watsonal castoria', '30ml', 1, 'boie', 'watsonal castoria', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (156, '4800011133447', 13, 'efficascent oil extra strength', '100ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (157, '4800011132938', 13, 'efficascent oil extreme', '50ml', 5, 'na', 'na', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (158, '48034678', 1, 'combantrin', '125mg/5ml 10ml', 1, 'combantrin', 'pyrantel embonate', 1);
INSERT INTO `tbl_items` (`id`, `item_id`, `subcat_id`, `item_name`, `item_description`, `item_critlimit`, `brand_name`, `generic_name`, `unit_id`) VALUES (159, '4804278041910', 1, 'combantrin', '125mg tablet', 5, 'combantrin', 'pyrantel embonate', 1);


#
# TABLE STRUCTURE FOR: tbl_logs
#

DROP TABLE IF EXISTS `tbl_logs`;

CREATE TABLE `tbl_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_date` datetime NOT NULL DEFAULT current_timestamp(),
  `log_task` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (1, '2021-04-10 15:00:23', 'POS Login', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (2, '2021-04-10 15:03:25', 'Added user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (3, '2021-04-10 15:03:47', 'Log in', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (4, '2021-04-10 15:03:54', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (5, '2021-04-10 15:05:25', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (6, '2021-04-10 15:08:18', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (7, '2021-04-10 15:08:22', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (8, '2021-04-10 15:09:10', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (9, '2021-04-10 15:09:20', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (10, '2021-04-10 15:09:28', 'Added unit', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (11, '2021-04-10 15:09:42', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (12, '2021-04-10 15:10:25', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (13, '2021-04-10 15:11:13', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (14, '2021-04-10 15:11:38', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (15, '2021-04-10 15:12:49', 'Added sub-category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (16, '2021-04-10 15:13:05', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (17, '2021-04-10 15:13:41', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (18, '2021-04-10 15:14:09', 'Added sub-category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (19, '2021-04-10 15:14:19', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (20, '2021-04-10 15:23:27', 'Added user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (21, '2021-04-10 15:23:31', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (22, '2021-04-10 15:25:41', 'Log in', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (23, '2021-04-10 15:30:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (24, '2021-04-10 15:34:01', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (25, '2021-04-10 15:41:01', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (26, '2021-04-10 15:41:20', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (27, '2021-04-10 15:41:21', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (28, '2021-04-10 15:43:42', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (29, '2021-04-10 15:44:23', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (30, '2021-04-10 15:45:22', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (31, '2021-04-10 15:45:43', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (32, '2021-04-10 15:49:27', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (33, '2021-04-10 15:49:50', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (34, '2021-04-10 15:50:18', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (35, '2021-04-10 15:51:35', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (36, '2021-04-10 15:52:04', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (37, '2021-04-10 15:53:10', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (38, '2021-04-10 15:53:21', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (39, '2021-04-10 15:53:22', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (40, '2021-04-10 15:55:21', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (41, '2021-04-10 15:57:04', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (42, '2021-04-10 15:57:37', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (43, '2021-04-10 15:59:08', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (44, '2021-04-10 15:59:49', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (45, '2021-04-10 16:00:28', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (46, '2021-04-10 16:01:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (47, '2021-04-10 16:04:19', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (48, '2021-04-10 16:06:08', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (49, '2021-04-10 16:06:51', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (50, '2021-04-10 16:07:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (51, '2021-04-10 16:08:41', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (52, '2021-04-10 16:08:41', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (53, '2021-04-10 16:10:07', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (54, '2021-04-10 16:10:23', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (55, '2021-04-10 16:11:09', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (56, '2021-04-10 16:11:11', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (57, '2021-04-10 16:13:03', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (58, '2021-04-10 16:16:35', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (59, '2021-04-10 16:16:35', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (60, '2021-04-10 16:17:11', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (61, '2021-04-10 16:18:12', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (62, '2021-04-10 16:18:24', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (63, '2021-04-10 16:19:02', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (64, '2021-04-10 16:20:14', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (65, '2021-04-10 16:20:15', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (66, '2021-04-10 16:23:19', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (67, '2021-04-10 16:24:23', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (68, '2021-04-10 16:25:12', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (69, '2021-04-10 16:25:25', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (70, '2021-04-10 16:26:17', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (71, '2021-04-10 16:27:34', 'Updated sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (72, '2021-04-10 16:27:51', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (73, '2021-04-10 16:29:54', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (74, '2021-04-10 16:30:44', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (75, '2021-04-10 16:31:08', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (76, '2021-04-10 16:31:46', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (77, '2021-04-10 16:33:51', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (78, '2021-04-10 16:35:46', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (79, '2021-04-10 16:35:52', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (80, '2021-04-10 16:36:33', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (81, '2021-04-10 16:37:49', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (82, '2021-04-10 16:38:14', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (83, '2021-04-10 16:38:47', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (84, '2021-04-10 16:39:57', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (85, '2021-04-10 16:40:19', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (86, '2021-04-10 16:41:44', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (87, '2021-04-10 16:41:47', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (88, '2021-04-10 16:42:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (89, '2021-04-10 16:42:50', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (90, '2021-04-10 16:43:44', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (91, '2021-04-10 16:44:05', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (92, '2021-04-10 16:45:51', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (93, '2021-04-10 16:47:44', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (94, '2021-04-10 16:48:25', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (95, '2021-04-10 16:48:55', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (96, '2021-04-10 16:49:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (97, '2021-04-10 16:50:18', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (98, '2021-04-10 16:50:43', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (99, '2021-04-10 16:51:08', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (100, '2021-04-10 16:51:58', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (101, '2021-04-10 16:52:32', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (102, '2021-04-10 16:54:43', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (103, '2021-04-10 16:55:39', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (104, '2021-04-10 16:58:08', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (105, '2021-04-10 16:58:29', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (106, '2021-04-10 16:58:51', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (107, '2021-04-10 16:59:39', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (108, '2021-04-10 17:00:00', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (109, '2021-04-10 17:01:02', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (110, '2021-04-10 17:01:41', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (111, '2021-04-10 17:02:09', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (112, '2021-04-10 17:03:40', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (113, '2021-04-10 17:04:11', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (114, '2021-04-10 17:05:25', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (115, '2021-04-10 17:06:49', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (116, '2021-04-10 17:06:51', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (117, '2021-04-10 17:07:52', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (118, '2021-04-10 17:08:22', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (119, '2021-04-10 17:10:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (120, '2021-04-10 17:11:06', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (121, '2021-04-10 17:12:25', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (122, '2021-04-10 17:12:41', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (123, '2021-04-10 17:13:10', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (124, '2021-04-10 17:14:25', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (125, '2021-04-10 17:14:26', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (126, '2021-04-10 17:14:46', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (127, '2021-04-10 17:15:32', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (128, '2021-04-10 17:16:30', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (129, '2021-04-10 17:17:41', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (130, '2021-04-10 17:18:14', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (131, '2021-04-10 17:19:01', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (132, '2021-04-10 17:19:03', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (133, '2021-04-10 17:19:44', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (134, '2021-04-10 17:19:44', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (135, '2021-04-10 17:21:06', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (136, '2021-04-10 17:22:11', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (137, '2021-04-10 17:23:13', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (138, '2021-04-10 17:23:14', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (139, '2021-04-10 17:23:28', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (140, '2021-04-10 17:25:59', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (141, '2021-04-10 17:26:11', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (142, '2021-04-10 17:26:30', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (143, '2021-04-10 17:28:27', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (144, '2021-04-10 17:28:33', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (145, '2021-04-10 17:29:10', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (146, '2021-04-10 17:30:08', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (147, '2021-04-10 17:31:45', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (148, '2021-04-10 17:33:04', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (149, '2021-04-10 17:33:57', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (150, '2021-04-10 17:35:11', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (151, '2021-04-10 17:36:50', 'Updated sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (152, '2021-04-10 17:37:02', 'Updated sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (153, '2021-04-10 17:37:30', 'Updated sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (154, '2021-04-10 17:37:54', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (155, '2021-04-10 17:39:56', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (156, '2021-04-10 17:41:28', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (157, '2021-04-10 17:41:38', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (158, '2021-04-10 17:45:26', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (159, '2021-04-10 17:46:31', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (160, '2021-04-10 17:48:04', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (161, '2021-04-10 17:48:19', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (162, '2021-04-10 17:50:41', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (163, '2021-04-10 17:52:22', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (164, '2021-04-10 17:52:26', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (165, '2021-04-10 17:52:45', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (166, '2021-04-10 17:53:48', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (167, '2021-04-10 17:54:40', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (168, '2021-04-10 17:55:24', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (169, '2021-04-10 17:55:31', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (170, '2021-04-10 17:56:03', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (171, '2021-04-10 17:57:14', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (172, '2021-04-10 17:58:37', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (173, '2021-04-10 17:58:53', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (174, '2021-04-10 18:00:10', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (175, '2021-04-10 18:00:36', 'Added product', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (176, '2021-04-10 18:00:59', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (177, '2021-04-10 18:01:52', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (178, '2021-04-10 18:05:10', 'Added sub-category', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (179, '2021-04-10 18:07:38', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (180, '2021-04-10 18:10:27', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (181, '2021-04-10 18:13:24', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (182, '2021-04-10 18:13:31', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (183, '2021-04-10 18:14:56', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (184, '2021-04-10 18:15:19', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (185, '2021-04-10 18:17:24', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (186, '2021-04-10 18:19:19', 'Added product', 4);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (187, '2021-04-10 18:19:32', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (188, '2021-04-10 18:24:39', 'Added product', 5);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (189, '2021-04-10 18:34:24', 'Log out', 5);


#
# TABLE STRUCTURE FOR: tbl_migrations
#

DROP TABLE IF EXISTS `tbl_migrations`;

CREATE TABLE `tbl_migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_migrations` (`version`) VALUES ('1');


#
# TABLE STRUCTURE FOR: tbl_orderdetails
#

DROP TABLE IF EXISTS `tbl_orderdetails`;

CREATE TABLE `tbl_orderdetails` (
  `orderdetails_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `item_id` varchar(20) DEFAULT NULL,
  `unit_id` tinyint(4) DEFAULT NULL,
  `orderdetails_quantity` int(11) DEFAULT NULL,
  `price_per_unit` decimal(9,2) DEFAULT NULL,
  PRIMARY KEY (`orderdetails_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_orderdetails_expiry
#

DROP TABLE IF EXISTS `tbl_orderdetails_expiry`;

CREATE TABLE `tbl_orderdetails_expiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderdetails_id` int(10) DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `rem_stocks` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_orderinventory
#

DROP TABLE IF EXISTS `tbl_orderinventory`;

CREATE TABLE `tbl_orderinventory` (
  `ordinv_id` int(11) NOT NULL AUTO_INCREMENT,
  `orderdetails_id` int(11) DEFAULT NULL,
  `ordinv_unit_price` decimal(7,2) DEFAULT NULL,
  `no_of_stocks` int(11) DEFAULT NULL,
  `inv_item_srp` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`ordinv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_orders
#

DROP TABLE IF EXISTS `tbl_orders`;

CREATE TABLE `tbl_orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_total` decimal(10,2) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_sales
#

DROP TABLE IF EXISTS `tbl_sales`;

CREATE TABLE `tbl_sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` int(11) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_total` decimal(9,2) DEFAULT NULL,
  `sales_or` varchar(20) DEFAULT NULL,
  `sales_tellerid` tinyint(4) DEFAULT NULL,
  `sales_discount` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_salesinfo
#

DROP TABLE IF EXISTS `tbl_salesinfo`;

CREATE TABLE `tbl_salesinfo` (
  `salesinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_id` int(11) DEFAULT NULL,
  `item_id` varchar(20) DEFAULT NULL,
  `unit_price` decimal(7,2) DEFAULT NULL,
  `no_of_items` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`salesinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_sessions
#

DROP TABLE IF EXISTS `tbl_sessions`;

CREATE TABLE `tbl_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0345uchkumqie0ss7609s9j1m6sen6c3', '192.168.8.114', 1618038861, '__ci_last_regenerate|i:1618038861;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0mfflilgei5kvb2jdiip4ai62qlleem4', '192.168.8.102', 1618044108, '__ci_last_regenerate|i:1618044108;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0pv80dlhq99b3fn5j868fv0eofvfevlm', '192.168.8.114', 1618044619, '__ci_last_regenerate|i:1618044619;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1705r9bgttc4ruah9flm82ll5ki3gm2v', '192.168.8.114', 1618042542, '__ci_last_regenerate|i:1618042542;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1rc40g5b446k2s2i2nj10jfrl4gb0jhr', '192.168.8.115', 1618048482, '__ci_last_regenerate|i:1618048482;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1sk93il7ab9i35o4fclpm7ol86c0mdn1', '192.168.8.114', 1618049047, '__ci_last_regenerate|i:1618049047;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2gsfc81050hrojb9ll1fj70pi0u7i25r', '192.168.8.115', 1618041973, '__ci_last_regenerate|i:1618041973;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2s23p5b5chhqm5442tpeulmat4kjgsrn', '192.168.8.102', 1618044536, '__ci_last_regenerate|i:1618044536;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2t298c2eu596asjg0en9824bifsvlrqc', '192.168.8.102', 1618045673, '__ci_last_regenerate|i:1618045673;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('34tb94cecoeua8s21647pbeimgrpq8jk', '::1', 1618036966, '__ci_last_regenerate|i:1618036966;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"3\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:13:\"brand solloso\";s:10:\"user_photo\";s:36:\"c220132c739559a00acd06f8250b2858.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 00:07:16\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('419chkg9ud3arm689eapr68j0jd70kef', '192.168.8.114', 1618048737, '__ci_last_regenerate|i:1618048737;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49ov4d9esp6ferip2nkfaqnc058l0gal', '192.168.8.115', 1618039844, '__ci_last_regenerate|i:1618039844;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bolad3tb3sinuskpdvecotq474n8vi3', '192.168.8.115', 1618045527, '__ci_last_regenerate|i:1618045527;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('58p3jv9cr52uchkufhsvm3diug6m1l17', '192.168.8.114', 1618044944, '__ci_last_regenerate|i:1618044944;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c85b7do308ga5u56itn6r6rrdrl7g3e', '192.168.8.115', 1618043447, '__ci_last_regenerate|i:1618043447;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5qnabunkiug0t3fblt5pq8vm0qr1fbv6', '192.168.8.102', 1618041456, '__ci_last_regenerate|i:1618041456;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6bl1vogh8lvhdedmspltv1sclvd79ij3', '192.168.8.114', 1618045992, '__ci_last_regenerate|i:1618045992;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6kjulud2rnlf11irsm2qpc769ta9q3et', '192.168.8.102', 1618049654, '__ci_last_regenerate|i:1618049654;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('700on6v658iugemv6p9gk5167gbno9d2', '192.168.8.114', 1618047601, '__ci_last_regenerate|i:1618047601;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('755bghuvao50klb3m8oolcrcocs5g17u', '192.168.8.115', 1618046914, '__ci_last_regenerate|i:1618046914;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7evanh41i85n81dshrm42v0fi6ir4fk8', '192.168.8.102', 1618045263, '__ci_last_regenerate|i:1618045263;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8h719toneqjh9bpn0n7jcs84t9etskd3', '192.168.8.115', 1618046295, '__ci_last_regenerate|i:1618046295;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('929ij1ka5nku2ehh283r8tki8imijt21', '192.168.8.115', 1618041632, '__ci_last_regenerate|i:1618041632;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9fog3okichepcmor9j35l0tulpugac2v', '192.168.8.114', 1618045614, '__ci_last_regenerate|i:1618045614;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9r1g7f1h1pokvgf4h5uf5mnuj7egv3mf', '192.168.8.115', 1618049161, '__ci_last_regenerate|i:1618049161;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ur3gp52sgrhi61923e5vbfh437bcpal', '192.168.8.102', 1618039142, '__ci_last_regenerate|i:1618039142;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aj6lhltntnm77oatrkj0acvhsl9mrns1', '192.168.8.114', 1618050070, '__ci_last_regenerate|i:1618049852;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ajrell4hgl89lfqgo1lo5u3pq4sblfer', '192.168.8.115', 1618048085, '__ci_last_regenerate|i:1618048085;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ar9ds3rqpv3a5lkn02i8ekmoqmpcq8je', '192.168.8.115', 1618045842, '__ci_last_regenerate|i:1618045842;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0rq9uanu1coeqiugdnl3ktoalpk2lb5', '::1', 1618036647, '__ci_last_regenerate|i:1618036647;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"3\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:13:\"brand solloso\";s:10:\"user_photo\";s:36:\"c220132c739559a00acd06f8250b2858.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 00:07:16\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('brhthllntc7nrj53cfgpk8t5p1qjdvi2', '192.168.8.115', 1618044506, '__ci_last_regenerate|i:1618044506;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c6s89p7c8i2521pbvqh5vb7vplor3cu2', '192.168.8.114', 1618038552, '__ci_last_regenerate|i:1618038552;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d1ndi4gbqkctg452pe93b3imv721ddii', '192.168.8.102', 1618040250, '__ci_last_regenerate|i:1618040250;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('djgd45umgk7l67t0oqu3v5hniud7vv1g', '192.168.8.102', 1618047927, '__ci_last_regenerate|i:1618047927;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e21cr56tbb68oso5mod1j83ct62ejipd', '192.168.8.114', 1618049852, '__ci_last_regenerate|i:1618049852;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fhlkdrqnjm1dd2oop9vr3qndtrc3in9b', '192.168.8.115', 1618042634, '__ci_last_regenerate|i:1618042634;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g8f2mrv9no3knunf4hmubin394itfvam', '192.168.8.114', 1618047994, '__ci_last_regenerate|i:1618047994;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ge13uud6nn5bsrhc284h1pggsutrl4op', '192.168.8.115', 1618047238, '__ci_last_regenerate|i:1618047238;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h2onmim4vltlfsucbtks6vat4ocd2bmt', '192.168.8.114', 1618041426, '__ci_last_regenerate|i:1618041426;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h7phfmrfctemki2um2jdfuao50h2cfoj', '192.168.8.102', 1618042161, '__ci_last_regenerate|i:1618042161;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hbqdk5am539lanofvmflcl5ulq4n68oj', '192.168.8.115', 1618049973, '__ci_last_regenerate|i:1618049973;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he3qjc0t1v86ekddktunjb8qtr12nacg', '192.168.8.114', 1618047188, '__ci_last_regenerate|i:1618047188;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hvl6kc08seqfhacc4j7f0cd6jefd63n0', '192.168.8.114', 1618043480, '__ci_last_regenerate|i:1618043480;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i7vntngpeou9nepaae1jinig575npf2a', '192.168.8.102', 1618042597, '__ci_last_regenerate|i:1618042597;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i9l5ajlrt5urqn4hsd3bph85d0sdbcgi', '192.168.8.115', 1618042275, '__ci_last_regenerate|i:1618042275;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iekp296t879ktvih015frj20sishada7', '192.168.8.115', 1618040994, '__ci_last_regenerate|i:1618040994;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('is98ug58442si0c9oe9irutolupej5te', '192.168.8.115', 1618040464, '__ci_last_regenerate|i:1618040464;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ivii0ausk87sri0povqu7emfi80tfkt8', '192.168.8.114', 1618040969, '__ci_last_regenerate|i:1618040969;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j9nkbvv9tt9dr6mnnnfmc4u247vk9c7m', '192.168.8.115', 1618041323, '__ci_last_regenerate|i:1618041323;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jadhqc2jd6vck3j89inbf1podvdnvm37', '192.168.8.114', 1618049476, '__ci_last_regenerate|i:1618049476;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kottbnmd0plnanpslf1vm4fe57aisulm', '192.168.8.102', 1618043011, '__ci_last_regenerate|i:1618043011;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kp0hslt4h0qhb599j6qsn40cpik3cl8g', '192.168.8.102', 1618046385, '__ci_last_regenerate|i:1618046385;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lmeojbl6blstjkra4j0o6a6vrlq1otgc', '::1', 1618038047, '__ci_last_regenerate|i:1618038047;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"3\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:13:\"brand solloso\";s:10:\"user_photo\";s:36:\"c220132c739559a00acd06f8250b2858.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 00:07:16\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lreslk5f6eutv8nkt2309up2r6ecm83e', '192.168.8.102', 1618038771, '__ci_last_regenerate|i:1618038771;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mh1uamf4tb95eblco75tsdlilunn15fa', '192.168.8.114', 1618046345, '__ci_last_regenerate|i:1618046345;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('miuaid9fo470f3lh6lridh6q5h33bugj', '192.168.8.114', 1618042014, '__ci_last_regenerate|i:1618042014;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mq2on467mpg6lmr598tgtd6igh5b9ii1', '192.168.8.114', 1618046763, '__ci_last_regenerate|i:1618046763;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n6p5lnccdb29dhv5gg6e26737v2ecv7d', '192.168.8.102', 1618048719, '__ci_last_regenerate|i:1618048719;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nb354r9r79j4dcfnjm2d1l2afg7312bs', '192.168.8.115', 1618050282, '__ci_last_regenerate|i:1618050282;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ndil2u095p2n1p4tna65gjkcnigl7r79', '192.168.8.102', 1618043395, '__ci_last_regenerate|i:1618043395;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('njh1ej90fio0hb159ag96e9thtc43eng', '192.168.8.114', 1618040482, '__ci_last_regenerate|i:1618040482;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nmj8dvvtsqkfoll3t61v5u5fckm1hlcs', '192.168.8.102', 1618047475, '__ci_last_regenerate|i:1618047475;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o66j8f3vt9ph3fa267njh207poe1r52p', '::1', 1618038235, '__ci_last_regenerate|i:1618038047;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"3\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:13:\"brand solloso\";s:10:\"user_photo\";s:36:\"c220132c739559a00acd06f8250b2858.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 00:07:16\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obq0qr25q0mv7vm4k17rktql3jv5rk7l', '192.168.8.114', 1618044281, '__ci_last_regenerate|i:1618044281;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ocifs46j1ua7v98org5japonesjkqb3o', '192.168.8.115', 1618045132, '__ci_last_regenerate|i:1618045132;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('odifkfsptl78em9dv6po6kvamtk71mhr', '192.168.8.115', 1618044106, '__ci_last_regenerate|i:1618044106;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oonn59jh6drhbe8r69ri9r56dksc0i1l', '192.168.8.102', 1618044884, '__ci_last_regenerate|i:1618044884;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('orclfhkalr49eepgd82o00lbvs0f88br', '192.168.8.102', 1618046066, '__ci_last_regenerate|i:1618046066;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ouauarm57l92a2psjph1v6r67k2khgbt', '192.168.8.115', 1618043748, '__ci_last_regenerate|i:1618043748;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9r4gsqq17uf62hfgj6akcpvrg0dk8jj', '192.168.8.102', 1618046772, '__ci_last_regenerate|i:1618046772;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pefc4i9essubfvh7kt6rmk1jcf6sm0l3', '192.168.8.115', 1618046610, '__ci_last_regenerate|i:1618046610;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pva6ecnie22vger9r5dd4foj4liqqs6n', '192.168.8.115', 1618049606, '__ci_last_regenerate|i:1618049606;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q063jepc3a4c8nocb5jo571antmaf04k', '192.168.8.114', 1618039482, '__ci_last_regenerate|i:1618039482;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q5bhja0mjndkkge4ged7ub66vbk24ns0', '192.168.8.115', 1618043002, '__ci_last_regenerate|i:1618043002;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qkqda1et34rvsgdl9toauqubau7rtlnj', '192.168.8.102', 1618049302, '__ci_last_regenerate|i:1618049302;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpd0qkhngtdgnekq94nv5l1hu7qsspqv', '192.168.8.102', 1618047107, '__ci_last_regenerate|i:1618047107;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qtrq2n9ggqs82a6qh4f3gnvm2s1nk3dn', '192.168.8.102', 1618049654, '__ci_last_regenerate|i:1618049654;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ro4em3j546be3dotj93d7hdusg54vm0b', '192.168.8.102', 1618043795, '__ci_last_regenerate|i:1618043795;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s0hkel9h7r94sm3bub9ct7gcinvsusch', '192.168.8.102', 1618041843, '__ci_last_regenerate|i:1618041843;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s1iire7tvv6linrqa3nti22qgi7jrhur', '192.168.8.102', 1618040724, '__ci_last_regenerate|i:1618040724;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('slgpv2ndqi095hq1tuuls4apukkunass', '192.168.8.114', 1618043896, '__ci_last_regenerate|i:1618043896;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t1nv3bjpoqqo93jrmlvpmrnkoagfjkmc', '192.168.8.115', 1618048860, '__ci_last_regenerate|i:1618048860;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tbnun9982m33o61pkrc6uedgvob0nngj', '192.168.8.102', 1618048347, '__ci_last_regenerate|i:1618048347;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tgfeflode3p8424dlbn1leto7li9chqe', '192.168.8.115', 1618050864, '__ci_last_regenerate|i:1618050864;user_id|s:1:\"5\";user_name|s:12:\"Jinky Mibato\";user_role|s:4:\"user\";user_photo|s:36:\"f629cc5b7b4db51d638b89258bb5123d.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"4\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:14:\"jhesorley laid\";s:10:\"user_photo\";s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:14:19\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ua7eoi14fs8mlgv7jo8b10opua27pkp8', '192.168.8.114', 1618040026, '__ci_last_regenerate|i:1618040026;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ub6anr6s2rndk2jf6612qdbfsaskvmon', '192.168.8.114', 1618048345, '__ci_last_regenerate|i:1618048345;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ueus3n2jjm2v89b881suhtmg4e84528v', '192.168.8.114', 1618045303, '__ci_last_regenerate|i:1618045303;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v89fsv87p778s6kghb2fdpcqb6sg8vtd', '192.168.8.114', 1618043169, '__ci_last_regenerate|i:1618043169;user_id|s:1:\"4\";user_name|s:14:\"Jhesorley Laid\";user_role|s:13:\"administrator\";user_photo|s:36:\"ab5ec9a08a148a11f65947cf4d0b34dc.jpg\";recents|a:0:{}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vi7rhsn1mgb1gmg98i6bik3rvl4e75mu', '192.168.8.102', 1618041125, '__ci_last_regenerate|i:1618041125;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"342316f5a3f3f88f4c829143eef8176e.jpg\";s:8:\"log_date\";s:19:\"2021-04-10 15:03:25\";}}');


#
# TABLE STRUCTURE FOR: tbl_subcategory
#

DROP TABLE IF EXISTS `tbl_subcategory`;

CREATE TABLE `tbl_subcategory` (
  `subcat_id` int(11) NOT NULL AUTO_INCREMENT,
  `subcat_name` varchar(50) DEFAULT NULL,
  `category_id` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`subcat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (1, 'branded', 1);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (2, 'generic', 1);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (3, 'herbal', 1);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (4, 'milk formula', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (5, 'toiletries and sanitary', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (6, 'soaps and detergents', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (7, 'ritemed', 1);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (8, 'beverages and drinks', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (9, 'foods and chips', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (10, 'beauty products', 3);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (11, 'miscellaneous', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (12, 'cereals and oatmeal', 2);
INSERT INTO `tbl_subcategory` (`subcat_id`, `subcat_name`, `category_id`) VALUES (13, 'liniments', 2);


#
# TABLE STRUCTURE FOR: tbl_temp_orderdetails
#

DROP TABLE IF EXISTS `tbl_temp_orderdetails`;

CREATE TABLE `tbl_temp_orderdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tmp_barcode` varchar(20) DEFAULT NULL,
  `tmp_date` date DEFAULT NULL,
  `tmp_quantity` int(11) DEFAULT NULL,
  `tmp_price` decimal(9,2) DEFAULT NULL,
  `tmp_srp` decimal(7,2) DEFAULT NULL,
  `tmp_expiry` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_ucjunc
#

DROP TABLE IF EXISTS `tbl_ucjunc`;

CREATE TABLE `tbl_ucjunc` (
  `ucjunc_id` int(11) NOT NULL AUTO_INCREMENT,
  `uc_id` int(11) DEFAULT NULL,
  `item_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ucjunc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (1, 1, '4806519380024');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (2, 2, '4804272979783');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (3, 3, '4800301902340');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (4, 4, '4800361314053');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (5, 5, '4800361388337');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (6, 6, '4800301902357');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (7, 7, '4800361403986');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (8, 8, '8712045020623');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (9, 9, '4800301902364');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (10, 10, '4800221240539');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (11, 11, '18906050757132');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (12, 12, '4800361348706');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (13, 13, '18906050757811');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (14, 14, '4800361348607');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (15, 15, '4806525170701');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (16, 16, '4800361348645');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (17, 17, '4800361397254');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (18, 18, '4806503122197');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (19, 19, '4800361363129');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (20, 20, '18906045600412');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (21, 21, '4800301903262');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (22, 22, '4800361373562');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (23, 23, '18908005368110');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (24, 24, '8906011513497');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (25, 25, '4804272979378');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (26, 26, '480427657207');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (27, 27, '4800153151248');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (28, 28, '4800301902517');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (29, 29, '4800153151231');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (30, 30, '4800301902524');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (31, 31, '4800301902500');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (32, 32, '4800221239427');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (33, 33, '4806523301862');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (34, 34, '8712045027165');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (35, 35, '4806523301893');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (36, 36, '4806501597980');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (37, 37, '4800301902494');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (38, 38, '4806501597454');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (39, 39, '9556001132468');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (40, 40, '4800301902487');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (41, 41, '4800301902463');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (42, 42, '9556001132048');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (43, 43, '4800301902845');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (44, 44, '4806523302241');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (45, 45, '9556001132291');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (46, 46, '4806501597416');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (47, 47, '4806523302067');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (48, 48, '4806523302029');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (49, 49, '6947790794020');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (50, 50, '4807788571137');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (51, 51, '4800274040018');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (52, 52, '4804276348042');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (53, 53, '4800186004917');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (54, 54, '8906016610030');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (55, 55, '4809012480017');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (56, 56, '4800888176851');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (57, 57, '4800343860776');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (58, 58, '4801010121244');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (59, 59, '4800888139641');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (60, 60, '4801010127314');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (61, 61, '4804274419607');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (62, 62, '4807788520906');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (63, 63, '4806789446826');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (64, 64, '4807788520890');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (65, 65, '4806789442163');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (66, 66, '6947790784830');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (67, 67, '18906016610112');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (68, 68, '4800888192882');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (69, 69, '4800888210449');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (70, 70, '4800204002024');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (71, 71, '4902430408097');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (72, 72, '4800204002017');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (73, 73, '4800135001417');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (74, 74, '4800888143891');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (75, 75, '4800204002048');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (76, 76, '48035880');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (77, 77, '4800135006542');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (78, 78, '4902430749756');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (79, 79, '8851932349130');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (80, 80, '8851932401289');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (81, 81, '4800888143860');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (82, 82, '4800067453513');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (83, 83, '8851932371551');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (84, 84, '4800067453544');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (85, 85, '4800135003113');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (86, 86, '8850007011187');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (87, 87, '4806515981348');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (88, 88, '4806789446833');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (89, 89, '4987176600769');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (90, 90, '4987176600776');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (91, 91, '4800204008651');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (92, 92, '4800003439526');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (93, 93, '4987176009678');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (94, 94, '4987176601285');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (95, 95, '4800888196255');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (96, 96, '8938503445207');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (97, 97, '4987176013491');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (98, 98, '4806789442156');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (99, 99, '4806501597973');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (100, 100, '4987176003430');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (101, 101, '4800119214680');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (102, 102, '4987176003423');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (103, 103, '4800135003107');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (104, 104, '4806789010003');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (105, 105, '4987072081808');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (106, 106, '4987072005538');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (107, 107, '7800888212429');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (108, 108, '8850007010869');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (109, 109, '4987072006160');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (110, 110, '4801010105107');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (111, 111, '4806526296820');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (112, 112, '48033459');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (113, 113, '8850007014492');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (114, 114, '4809030034018');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (115, 115, '9318637043330');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (116, 116, '9556006062074');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (117, 117, '4800067551165');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (118, 118, '9318637044009');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (119, 119, '30707387005086');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (120, 120, '4800119219128');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (121, 121, '30707387065974');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (122, 122, '4804279363677');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (123, 123, '48038683');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (124, 124, '7707331802084');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (125, 125, '4806016000777');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (126, 126, '4800011121512');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (127, 127, '302993921400');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (128, 128, '4800011122212');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (129, 129, '9318637043316');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (130, 130, '4800135003183');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (131, 131, '8850007814405');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (132, 132, '4809012730952');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (133, 133, '8850007814382');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (134, 134, '8850007814290');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (135, 135, '8850007814429');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (136, 136, '4800135003268');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (137, 137, '4806530875752');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (138, 138, '8850007814375');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (139, 139, '382906702012');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (140, 140, '4800136111054');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (141, 141, '4800119222036');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (142, 142, '4806530871143');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (143, 143, '4800119211290');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (144, 144, '4809012480024');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (145, 145, '4806507831071');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (146, 146, '9556006060636');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (147, 147, '4800011121536');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (148, 148, '4804274682445');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (149, 149, '4800011122236');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (150, 150, '4800011159034');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (151, 151, '4800011159041');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (152, 152, '4806502790274');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (153, 153, '48035156');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (154, 154, '4800011133430');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (155, 155, '4806502790267');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (156, 156, '4800011133447');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (157, 157, '4800011132938');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (158, 158, '48034678');
INSERT INTO `tbl_ucjunc` (`ucjunc_id`, `uc_id`, `item_id`) VALUES (159, 159, '4804278041910');


#
# TABLE STRUCTURE FOR: tbl_unit
#

DROP TABLE IF EXISTS `tbl_unit`;

CREATE TABLE `tbl_unit` (
  `unit_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `unit_desc` varchar(15) DEFAULT NULL,
  `unit_sh` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unit` (`unit_id`, `unit_desc`, `unit_sh`) VALUES (1, 'pieces', 'pcs');


#
# TABLE STRUCTURE FOR: tbl_unitconvert
#

DROP TABLE IF EXISTS `tbl_unitconvert`;

CREATE TABLE `tbl_unitconvert` (
  `uc_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id1` tinyint(4) DEFAULT NULL,
  `unit_id2` tinyint(4) DEFAULT NULL,
  `uc_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`uc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (1, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (2, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (3, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (4, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (5, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (6, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (7, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (8, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (9, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (10, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (11, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (12, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (13, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (14, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (15, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (16, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (17, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (18, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (19, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (20, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (21, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (22, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (23, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (24, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (25, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (26, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (27, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (28, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (29, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (30, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (31, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (32, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (33, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (34, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (35, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (36, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (37, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (38, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (39, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (40, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (41, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (42, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (43, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (44, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (45, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (46, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (47, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (48, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (49, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (50, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (51, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (52, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (53, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (54, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (55, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (56, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (57, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (58, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (59, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (60, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (61, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (62, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (63, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (64, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (65, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (66, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (67, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (68, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (69, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (70, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (71, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (72, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (73, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (74, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (75, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (76, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (77, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (78, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (79, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (80, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (81, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (82, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (83, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (84, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (85, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (86, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (87, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (88, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (89, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (90, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (91, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (92, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (93, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (94, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (95, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (96, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (97, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (98, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (99, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (100, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (101, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (102, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (103, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (104, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (105, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (106, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (107, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (108, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (109, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (110, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (111, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (112, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (113, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (114, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (115, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (116, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (117, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (118, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (119, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (120, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (121, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (122, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (123, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (124, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (125, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (126, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (127, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (128, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (129, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (130, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (131, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (132, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (133, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (134, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (135, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (136, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (137, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (138, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (139, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (140, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (141, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (142, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (143, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (144, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (145, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (146, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (147, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (148, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (149, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (150, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (151, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (152, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (153, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (154, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (155, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (156, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (157, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (158, 1, 1, 1);
INSERT INTO `tbl_unitconvert` (`uc_id`, `unit_id1`, `unit_id2`, `uc_number`) VALUES (159, 1, 1, 1);


#
# TABLE STRUCTURE FOR: tbl_user_login
#

DROP TABLE IF EXISTS `tbl_user_login`;

CREATE TABLE `tbl_user_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_name` varchar(20) NOT NULL,
  `login_pass` char(32) NOT NULL,
  `login_level` varchar(25) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_user_login` (`login_id`, `login_name`, `login_pass`, `login_level`, `user_id`) VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator', 1);
INSERT INTO `tbl_user_login` (`login_id`, `login_name`, `login_pass`, `login_level`, `user_id`) VALUES (4, 'jhes', '25d55ad283aa400af464c76d713c07ad', 'administrator', 4);
INSERT INTO `tbl_user_login` (`login_id`, `login_name`, `login_pass`, `login_level`, `user_id`) VALUES (5, 'mj739', '25d55ad283aa400af464c76d713c07ad', 'user', 5);


#
# TABLE STRUCTURE FOR: tbl_user_meta
#

DROP TABLE IF EXISTS `tbl_user_meta`;

CREATE TABLE `tbl_user_meta` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(60) NOT NULL,
  `user_phone` varchar(30) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_photo` varchar(100) NOT NULL,
  `user_bio` text NOT NULL,
  `user_status` char(15) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (1, 'system admin', '+639108973533', 'junry.s.solloso@gmail.com', 'san jose, dinagat islands', '342316f5a3f3f88f4c829143eef8176e.jpg', 'hobbyist and enthusiast programmer.', 'active', 0);
INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (4, 'jhesorley laid', '09090909000', 'jhes@gmail.com', 'san jose, dinagat islands', 'ab5ec9a08a148a11f65947cf4d0b34dc.jpg', 'na', 'active', 0);
INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (5, 'jinky mibato', '09090909000', 'jinky@gmail.com', 'san juan, san jose, dinagat islands', 'f629cc5b7b4db51d638b89258bb5123d.jpg', 'pharmacist', 'active', 0);


#
# TABLE STRUCTURE FOR: temp_salesinfo
#

DROP TABLE IF EXISTS `temp_salesinfo`;

CREATE TABLE `temp_salesinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_id` int(11) DEFAULT NULL,
  `item_id` varchar(20) DEFAULT NULL,
  `unit_price` decimal(7,2) DEFAULT NULL,
  `no_of_items` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

